killall firefox-esr > /dev/null 2>&1
./r1.sh
sleep 20
./r2.sh
sleep 80
./r2.sh